<?php
require_once 'Model/Note.php';

class NoteController {
    private $noteModel;

    public function __construct($pdo) {
        $this->noteModel = new Note($pdo);
    }

    public function index() {
        $notes = $this->noteModel->getAllNotes();
        require 'View/notes.php';
    }

    public function addNote() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = $_POST['title'];
            $content = $_POST['content'];
            $this->noteModel->addNote($title, $content);
            header('Location: index.php');
        } else {
            require 'View/add_note.php';
        }
    }

    // API Functions
    public function apiGetNotes() {
        $notes = $this->noteModel->getAllNotes();
        echo json_encode($notes);
    }

    public function apiAddNote() {
        $data = json_decode(file_get_contents('php://input'), true);
        if ($data && isset($data['title']) && isset($data['content'])) {
            $this->noteModel->addNote($data['title'], $data['content']);
            echo json_encode(['message' => 'Note added successfully']);
        } else {
            echo json_encode(['error' => 'Invalid input']);
        }
    }
}
?>
