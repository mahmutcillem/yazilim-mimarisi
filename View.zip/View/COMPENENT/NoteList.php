<?php
class NoteList {
    public static function render($notes) {
        echo '<ul>';
        foreach ($notes as $note) {
            echo '<li>';
            echo '<h2>' . htmlspecialchars($note['title']) . '</h2>';
            echo '<p>' . nl2br(htmlspecialchars($note['content'])) . '</p>';
            echo '</li>';
        }
        echo '</ul>';
    }
}
?>
