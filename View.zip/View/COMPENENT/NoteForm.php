<?php
class NoteForm {
    public static function render() {
        echo '<form method="POST" action="index.php?action=add">';
        echo '<label for="title">Title:</label>';
        echo '<input type="text" id="title" name="title" required>';
        echo '<br>';
        echo '<label for="content">Content:</label>';
        echo '<textarea id="content" name="content" required></textarea>';
        echo '<br>';
        echo '<button type="submit">Add</button>';
        echo '</form>';
    }
}
?>
